/**
 * exports 전역객체
 * exports.함수이름을 써서 메인 파일에서 사용 가능
 */
exports.add = function(a,b) {
	return a + b;
}
exports.sub = function(a,b) {
	return a - b;
}
exports.mul = function(a,b) {
	return a * b;
}
exports.div = function(a,b) {
	return a / b;
}